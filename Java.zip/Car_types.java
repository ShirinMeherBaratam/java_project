import java.util.*;
//import java.util.*;
import java.lang.*;
//import java.lang.*;
import java.io.*;
class Car_types {
    public int car(int pp) 
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("---------------");
        System.out.println("1->ROLLS ROYCE");
        System.out.println("2->AUDI");
        System.out.println("3->SUZUKI");
        System.out.println("4->SWIFT");
        System.out.println("5->TATA");
        System.out.println("Enter the car type you want ->Press corresponding numb");
        int choice1 = sc.nextInt();
	   int k=choice1;
        System.out.println("Car type is succesfully selected");
        Type t = new Type();
        t.comfy(k,pp);
        return choice1;
        // model m=new model();
        // m.model_method();

    }

}