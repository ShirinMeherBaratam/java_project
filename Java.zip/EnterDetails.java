import java.util.*;
//import java.util.*;
import java.lang.*;
//import java.lang.*;
import java.io.*;
//import amma.*;
class EnterDetails
{
		
		
	public int Details()
	{
        String Ptime,Pdate,Pdes;
		int dy;
		Scanner sc =new Scanner(System.in);  
		System.out.println("Enter The Required details:");
		System.out.print("Enter Pickup Destination:");
	    Pdes=sc.nextLine();
		System.out.print("\nEnter Pickup Date:");
		Pdate=sc.nextLine();
		System.out.print("Enter Pickup Time:");
		Ptime=sc.nextLine();
		System.out.print("Enter the No.of days:");
		dy=sc.nextInt();
		//return dy;
        
    try {
        FileWriter fw = new FileWriter("Data.txt",true);  
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write("\n"+Pdes+","+Pdate+","+Ptime+","+dy);
        System.out.println("Data was appended to the file successfully.");
        bw.close();
      } 
    catch (IOException e) 
      {
        System.out.println("An error occurred while trying to write to the file.");
        e.printStackTrace();
      }
	return dy;	
    }
}
