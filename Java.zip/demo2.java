import java.util.*;
//import java.util.*;
import java.lang.*;
//import java.lang.*;
import java.io.*;
class demo2{

    public void details()
	 {
        Scanner sc =new Scanner(System.in);
		EnterDetails e= new EnterDetails();
		int pp=e.Details();
	
        Car_types ct = new Car_types();
        ct.car(pp);
	
        // type cmfy=new comfy();

    }
}