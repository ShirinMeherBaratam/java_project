package VR_cars;
import java.util.*;
//import java.util.*;
import java.lang.*;
//import java.lang.*;
import java.io.*;
interface funint
{
	void calc(int x,int dy);
}
 public class Type {
	
    public void comfy(int k,int dy) {
    Scanner sc = new Scanner(System.in);
	String m1[]=new String[5];
	String m2[]=new String[5];
	String m3[]=new String[5];
	String m4[]=new String[5];
	String m5[]=new String[5];
	//int k;
        System.out.println("--------------");
        System.out.println("Enter Your Comfort Type");
        System.out.println("1->AC TYPE");
        System.out.println("2->NON-AC TYPE");
        int choice = sc.nextInt();
        if(choice == 1)
			{
			System.out.println("Here are Your Ac CARS Available Models");
			if(k==1)
			{
				m1[0]="Rolls Royce 1 (4000/- PER DAY)";
				m1[1]="Rolls Royce 2 (5000/- PER DAY)";
				m1[2]="Rolls Royce 3(60000/- PER DAY)";
					System.out.println("1->"+m1[0]);
					System.out.println("2->"+m1[1]);
					System.out.println("3->"+m1[2]);
			}
			if(k==2)
			{
				m2[0]="AUDI 1(4000/- PER DAY)";
				m2[1]="AUDI 2(5000/- PER DAY)";
				m2[2]="AUDI 3(6000/- PER DAY)";
					System.out.println("1->"+m2[0]);
					System.out.println("2->"+m2[1]);
					System.out.println("3->"+m2[2]);
			}
			if(k==3)
			{
				m3[0]="SUZUKI 1(4000/- PER DAY)";
				m3[1]="SUZUKI 2(5000/- PER DAY)";
				m3[2]="SUZUKI 3(6000/- PER DAY)";
					System.out.println("1->"+m3[0]);
					System.out.println("2->"+m3[1]);
					System.out.println("3->"+m3[2]);
			}
			if(k==4)
			{
				m4[0]="SWIFT 1(4000/- PER DAY)";
				m4[1]="SWIFT 2(5000/- PER DAY)";
				m4[2]="SWIFT 3(6000/- PER DAY)";
					System.out.println("1->"+m4[0]);
					System.out.println("2->"+m4[1]);
					System.out.println("3->"+m4[2]);
			}
			if(k==5)
			{
				m5[0]="TATA 1(4000/- PER DAY)";
				m5[1]="TATA 2(5000/- PER DAY)";
				m5[2]="TATA 3(6000/- PER DAY)";
					System.out.println("1->"+m5[0]);
					System.out.println("2->"+m5[1]);
					System.out.println("3->"+m5[2]);
			}
			System.out.println("Enter The model of the car you want");
			int x=sc.nextInt();
			System.out.println("Succesfully Booked............");
			funint c=(int x3,int y)->{ if(x3==1)
								{
									System.out.println("The Total amount for Your trip is :"+4000*y);
								}
								if(x3==2)
								{
									System.out.println("The Total amount for Your trip is :"+5000*y);
								}
								if(x3==3)
								{
									System.out.println("The Total amount for Your trip is :"+6000*y);
								}
		
							};
			c.calc(x,dy);
			
			}
        if (choice == 2) 
		{
				System.out.println("Here are Your NON-AC CARS");
				
			if(k==1)
			{
				m1[0]="Non Ac Rolls Royce 1 (2000/- PER DAY)";
				m1[1]="Non Ac Rolls Royce 2 (3000/- PER DAY)";
				m1[2]="Non Ac Rolls Royce 3(4000/- PER DAY)";
					System.out.println("1->"+m1[0]);
					System.out.println("2->"+m1[1]);
					System.out.println("3->"+m1[2]);
			}
			if(k==2)
			{
				m2[0]="Non Ac AUDI 1(2000/- PER DAY)";
				m2[1]="Non Ac AUDI 2(3000/- PER DAY)";
				m2[2]="Non Ac AUDI 3(4000/- PER DAY)";
				System.out.println("1->"+m2[0]);
				System.out.println("2->"+m2[1]);
				System.out.println("3->"+m2[2]);
			}
			if(k==3)
			{
				m3[0]="Non Ac SUZUKI 1(2000/- PER DAY)";
				m3[1]="Non Ac SUZUKI 2(3000/- PER DAY)";
				m3[2]="Non Ac SUZUKI 3(4000/- PER DAY)";
				System.out.println("1->"+m3[0]);
				System.out.println("2->"+m3[1]);
				System.out.println("3->"+m3[2]);
			}
			if(k==4)
			{
				m4[0]="Non Ac SWIFT 1(2000/- PER DAY)";
				m4[1]="Non Ac SWIFT 2(3000/- PER DAY)";
				m4[2]="Non Ac SWIFT 3(4000/- PER DAY)";
				System.out.println("1->"+m4[0]);
				System.out.println("2->"+m4[1]);
				System.out.println("3->"+m4[2]);
			}
			if(k==5)
			{
				m5[0]="Non Ac TATA 1(2000/- PER DAY)";
				m5[1]="Non Ac TATA 2(3000/- PER DAY)";
				m5[2]="Non Ac TATA 3(4000/- PER DAY)";
				System.out.println("1->"+m5[0]);
				System.out.println("2->"+m5[1]);
				System.out.println("3->"+m5[2]);
			}
			System.out.println("Enter The model of the car you want");
			int x1=sc.nextInt();
			System.out.println("Succesfully Booked............");
			funint f=(int x2,int y1)->
							{ if(x2==1)
								{
									System.out.println("The Total amount for Your trip is :"+2000*y1);
								}
								if(x2==2)
								{
									System.out.println("The Total amount for Your trip is :"+3000*y1);
								}
								if(x2==3)
								{
									System.out.println("The Total amount for Your trip is :"+4000*y1);
								}
		
							};
			f.calc(x1,dy);
						}

    }

	
}