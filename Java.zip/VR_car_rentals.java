import java.util.*;
//import java.util.*;
import java.lang.*;
//import java.lang.*;
import java.io.*;
class VR_car_rentals
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("\n[1] -> Login\n [2] -> Signup\n [3] -> Exit");
		int choice;
		do
		{
			System.out.println("Enter your choice:");
			choice =sc.nextInt();
			switch(choice)
			{
				case 1:
				{
					Test t = new Test();
					t.login();
					break;
				}
				case 2:
				{
					Registration r = new Registration();
					r.signup();
					break;
				}
				//case 3:
				//{
				//	Check c = new Check();
				//	c.status();
				//	break;
				//}
				case 3:
				{
					System.out.println("Completed....");
					break;
				}
				default :
				{
					System.out.println("Error option 1-4 only!...");
				}
			}
		}while(choice!=3);
		demo2 demo = new demo2();
		demo.details();
	}
}
class EnterDetails
{
		
		
	public int Details()
	{
        String Ptime,Pdate,Pdes;
		int dy;
		Scanner sc =new Scanner(System.in);  
		System.out.println("Enter The Required details:");
		System.out.print("Enter Pickup Destination:");
	    Pdes=sc.nextLine();
		System.out.print("\nEnter Pickup Date:");
		Pdate=sc.nextLine();
		System.out.print("Enter Pickup Time:");
		Ptime=sc.nextLine();
		System.out.print("Enter the No.of days:");
		dy=sc.nextInt();
		//return dy;
        
    try {
        FileWriter fw = new FileWriter("Data.txt",true);  
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write("\n"+Pdes+","+Pdate+","+Ptime+","+dy);
        System.out.println("Data was appended to the file successfully.");
        bw.close();
      } 
    catch (IOException e) 
      {
        System.out.println("An error occurred while trying to write to the file.");
        e.printStackTrace();
      }
	return dy;	
    }
}

class Car_types {
    public int car(int pp) 
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("---------------");
        System.out.println("1->ROLLS ROYCE");
        System.out.println("2->AUDI");
        System.out.println("3->SUZUKI");
        System.out.println("4->SWIFT");
        System.out.println("5->TATA");
        System.out.println("Enter the car type you want ->Press corresponding numb");
        int choice1 = sc.nextInt();
	   int k=choice1;
        System.out.println("Car type is succesfully selected");
        Type t = new Type();
        t.comfy(k,pp);
        return choice1;
        // model m=new model();
        // m.model_method();

    }

}
class Type {
	
    public void comfy(int k,int dy) {
    Scanner sc = new Scanner(System.in);
	String m1[]=new String[5];
	String m2[]=new String[5];
	String m3[]=new String[5];
	String m4[]=new String[5];
	String m5[]=new String[5];
	//int k;
        System.out.println("--------------");
        System.out.println("Enter Your Comfort Type");
        System.out.println("1->AC TYPE");
        System.out.println("2->NON-AC TYPE");
        int choice = sc.nextInt();
        if (choice == 1)
	{
		System.out.println("Here are Your Ac CARS Available Models");
		if(k==1)
		{
			m1[0]="Rolls Royce 1 (4000/- PER DAY)";
			m1[1]="Rolls Royce 2 (5000/- PER DAY)";
			m1[2]="Rolls Royce 3(60000/- PER DAY)";
	    		System.out.println("1->"+m1[0]);
	    		System.out.println("2->"+m1[1]);
	    		System.out.println("3->"+m1[2]);
		}
		if(k==2)
		{
			m2[0]="AUDI 1(4000/- PER DAY)";
			m2[1]="AUDI 2(5000/- PER DAY)";
			m2[2]="AUDI 3(6000/- PER DAY)";
	    		System.out.println("1->"+m2[0]);
	    		System.out.println("2->"+m2[1]);
	    		System.out.println("3->"+m2[2]);
		}
		if(k==3)
		{
			m3[0]="SUZUKI 1(4000/- PER DAY)";
			m3[1]="SUZUKI 2(5000/- PER DAY)";
			m3[2]="SUZUKI 3(6000/- PER DAY)";
	    		System.out.println("1->"+m3[0]);
	    		System.out.println("2->"+m3[1]);
	    		System.out.println("3->"+m3[2]);
		}
		if(k==4)
		{
			m4[0]="SWIFT 1(4000/- PER DAY)";
			m4[1]="SWIFT 2(5000/- PER DAY)";
			m4[2]="SWIFT 3(6000/- PER DAY)";
	    		System.out.println("1->"+m4[0]);
	    		System.out.println("2->"+m4[1]);
	    		System.out.println("3->"+m4[2]);
		}
		if(k==5)
		{
			m5[0]="TATA 1(4000/- PER DAY)";
			m5[1]="TATA 2(5000/- PER DAY)";
			m5[2]="TATA 3(6000/- PER DAY)";
	    		System.out.println("1->"+m5[0]);
	    		System.out.println("2->"+m5[1]);
	    		System.out.println("3->"+m5[2]);
		}
		System.out.println("Enter The model of the car you want");
		int x=sc.nextInt();
		System.out.println("Succesfully Booked............");
		if(x==1)
		{
		System.out.println("The Total amount for Your trip is :"+4000*dy);
		}
		if(x==2)
		{
		System.out.println("The Total amount for Your trip is :"+5000*dy);
		}
		if(x==3)
		{
		System.out.println("The Total amount for Your trip is :"+6000*dy);
		}
		
        }
        if (choice == 2) 
	{
        	System.out.println("Here are Your NON-AC CARS");
			
		if(k==1)
		{
			m1[0]="Non Ac Rolls Royce 1 (2000/- PER DAY)";
			m1[1]="Non Ac Rolls Royce 2 (3000/- PER DAY)";
			m1[2]="Non Ac Rolls Royce 3(4000/- PER DAY)";
	    		System.out.println("1->"+m1[0]);
	    		System.out.println("2->"+m1[1]);
	    		System.out.println("3->"+m1[2]);
		}
		if(k==2)
		{
			m2[0]="Non Ac AUDI 1(2000/- PER DAY)";
			m2[1]="Non Ac AUDI 2(3000/- PER DAY)";
			m2[2]="Non Ac AUDI 3(4000/- PER DAY)";
	    	System.out.println("1->"+m2[0]);
	    	System.out.println("2->"+m2[1]);
	    	System.out.println("3->"+m2[2]);
		}
		if(k==3)
		{
			m3[0]="Non Ac SUZUKI 1(2000/- PER DAY)";
			m3[1]="Non Ac SUZUKI 2(3000/- PER DAY)";
			m3[2]="Non Ac SUZUKI 3(4000/- PER DAY)";
	    	System.out.println("1->"+m3[0]);
	    	System.out.println("2->"+m3[1]);
	    	System.out.println("3->"+m3[2]);
		}
		if(k==4)
		{
			m4[0]="Non Ac SWIFT 1(2000/- PER DAY)";
			m4[1]="Non Ac SWIFT 2(3000/- PER DAY)";
			m4[2]="Non Ac SWIFT 3(4000/- PER DAY)";
	    	System.out.println("1->"+m4[0]);
	    	System.out.println("2->"+m4[1]);
	    	System.out.println("3->"+m4[2]);
		}
		if(k==5)
		{
			m5[0]="Non Ac TATA 1(2000/- PER DAY)";
			m5[1]="Non Ac TATA 2(3000/- PER DAY)";
			m5[2]="Non Ac TATA 3(4000/- PER DAY)";
	    	System.out.println("1->"+m5[0]);
	    	System.out.println("2->"+m5[1]);
	    	System.out.println("3->"+m5[2]);
		}
		System.out.println("Enter The model of the car you want");
		int x1=sc.nextInt();
		System.out.println("Succesfully Booked............");
		if(x1==1)
		{
		System.out.println("The Total amount for Your trip is :"+2000*dy);
		}
		if(x1==2)
		{
		System.out.println("The Total amount for Your trip is :"+3000*dy);
		}
		if(x1==3)
		{
		System.out.println("The Total amount for Your trip is :"+4000*dy);
		}
	
        }

    }

	
}
class demo2{

    public void details()
	 {
        Scanner sc =new Scanner(System.in);
		EnterDetails e= new EnterDetails();
		int pp=e.Details();
	
        Car_types ct = new Car_types();
        ct.car(pp);
	
        // type cmfy=new comfy();

    }
}
				
				
		