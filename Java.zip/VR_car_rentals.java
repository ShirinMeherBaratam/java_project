import java.util.*;
//import java.util.*;
import java.lang.*;
//import java.lang.*;
import java.io.*;
import VR_cars.* ;
class VR_car_rentals
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("\n[1] -> Login\n [2] -> Signup\n [3] -> Exit");
		int choice;
		do
		{
			System.out.println("Enter your choice:");
			choice =sc.nextInt();
			switch(choice)
			{
				case 1:
				{
					VR_cars.Test t = new VR_cars.Test();
					t.login();
					break;
				}
				case 2:
				{
					VR_cars.Registration r = new VR_cars.Registration();
					r.signup();
					break;
				}
				//case 3:
				//{
				//	VR_cars.Check c = new VR_cars.Check();
				//	c.status();
				//	break;
				//}
				case 3:
				{
					System.out.println("Completed....");
					break;
				}
				default :
				{
					System.out.println("Error option 1-4 only!...");
				}
			}
		}while(choice!=3);
		VR_cars.demo2 demo = new VR_cars.demo2();
		demo.details();
	}
}