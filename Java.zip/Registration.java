import java.util.*;
//import java.util.*;
import java.lang.*;
//import java.lang.*;
import java.io.*;


public class Registration {

    static Register register = new Register();

    public void signup() {

            Scanner scanner = new Scanner(System.in);
            System.out.print(" Enter firstName => ");
            String firstName = scanner.nextLine();
            register.setFirstName(firstName);

            System.out.print(" Enter lastName => ");
            String lastName = scanner.nextLine();
            register.setLastName(lastName);

            System.out.print(" Enter userName => ");
            String userName = scanner.nextLine();
            register.setUserName(userName);

            System.out.print(" Enter password => ");
            String password = scanner.nextLine();
            register.setPassword(password);

            System.out.print(" Enter emailId => ");
            String emailId = scanner.nextLine();
            register.setEmailId(emailId);

            System.out.print(" Enter phoneNo => ");
            long phoneNo = scanner.nextLong();
            register.setPhoneNo(phoneNo);
		  try {
        			FileWriter fw = new FileWriter("car_rentals.txt",true);  
        			BufferedWriter bw = new BufferedWriter(fw);
        			bw.write("\n"+firstName+","+lastName+","+userName+","+password+","+emailId+","+phoneNo+"\n");
        			System.out.println("Data was appended to the file successfully.");
        			bw.close();
      	} 
    		catch (IOException e) 
      	{
        			System.out.println("An error occurred while trying to write to the file.");
        			e.printStackTrace();
      	}
		 System.out.println(register.toString());
	}
}
